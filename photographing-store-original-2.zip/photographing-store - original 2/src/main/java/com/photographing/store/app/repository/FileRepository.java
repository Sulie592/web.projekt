package com.photographing.store.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.photographing.store.app.modal.File;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

// This interface interacts with database for data persistence
public interface FileRepository extends JpaRepository<File, Long> {
    @Query(value = "select * from files where name like %:fileName% order by :sort", nativeQuery = true)
    List<File> findAllByNameLike(@Param("fileName") String fileName, @Param("sort") String sort);
}
